import Multiplex
import Division
import Multiplex_IEEE754

def main():

     #Multiplex.multiplexFunc(22, -2)
     #Division.division(20, 2)
     Multiplex_IEEE754.multiplex(55555555555.555, 105.875)
     print(Multiplex_IEEE754.floatToBinary(55555555555.5*105.875) == Multiplex_IEEE754.multiplex(55555555555.555, 105.875))
     print(55555555555.555 *105.875)
if __name__ == '__main__':
    main()



