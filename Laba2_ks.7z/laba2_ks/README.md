# Laba2_KS

